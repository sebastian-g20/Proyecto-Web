from django.shortcuts import render
from .models import Producto
from django.shortcuts import get_object_or_404
from rest_framework.views import APIView

def producto_lista(request):
    productos = Producto.objects.select_related('categoria').all()
    contexto = {'productos': productos}
    return render(request, 'catalogo/lista.html', contexto)

class ProductoDetalle(APIView):
    def get(self, request, pk):
        producto = get_object_or_404(Producto, pk=pk)
        s = ProductoSerializer(producto)
        return Response(s.data)
    
    def put(self, request, pk):
        producto = get_object_or_404(Producto, pk=pk)
        s = ProductoSerializer(producto, data=request.data)
        s.is_valid(raise_exception=True)
        s.save()
        return Response(s.data)